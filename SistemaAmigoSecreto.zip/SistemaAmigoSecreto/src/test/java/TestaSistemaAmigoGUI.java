import br.ufpb.dcx.amigosecreto.AmigoInexistenteException;
import br.ufpb.dcx.amigosecreto.SistemaAmigo;

import javax.swing.JOptionPane;

public class TestaSistemaAmigoGUI {
    public static void main(String[] args) {
        SistemaAmigo sistema = new SistemaAmigo();

        try {
            // b) Ler quantidade de amigos
            int quantidade = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de amigos participantes:"));

            // c) Cadastrar amigos
            for (int i = 0; i < quantidade; i++) {
                String nome = JOptionPane.showInputDialog("Digite o nome do amigo " + (i + 1) + ":");
                String email = JOptionPane.showInputDialog("Digite o e-mail do amigo " + (i + 1) + ":");
                sistema.cadastraAmigo(nome, email);
            }

            // d) Cadastrar resultados do sorteio
            for (int i = 0; i < quantidade; i++) {
                String emailPessoa = JOptionPane.showInputDialog("Digite o e-mail de quem participou do sorteio:");
                String emailSorteado = JOptionPane.showInputDialog("Digite o e-mail do amigo secreto sorteado por essa pessoa:");
                sistema.configuraAmigoSecretoDe(emailPessoa, emailSorteado);
            }

            // e) Enviar mensagem de um amigo para todos
            String remetente = JOptionPane.showInputDialog("Digite o e-mail do remetente da mensagem:");
            String texto = JOptionPane.showInputDialog("Digite o texto da mensagem:");
            int anonimaOp = JOptionPane.showConfirmDialog(null, "A mensagem é anônima?", "Anonimato", JOptionPane.YES_NO_OPTION);
            boolean ehAnonima = (anonimaOp == JOptionPane.YES_OPTION);

            sistema.enviarMensagemParaTodos(texto, remetente, ehAnonima);

            JOptionPane.showMessageDialog(null, "br.ufpb.dcx.amigosecreto.Mensagem enviada com sucesso!");

        } catch (AmigoInexistenteException e) {
            JOptionPane.showMessageDialog(null, "Erro: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Erro: Valor numérico inválido.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro inesperado: " + e.getMessage());
        }
    }
}
