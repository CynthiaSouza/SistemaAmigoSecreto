import br.ufpb.dcx.amigosecreto.*;

public class TestaSistemaAmigo {
    public static void main(String[] args) {
        SistemaAmigo sistema = new SistemaAmigo();

        // a) Cadastrando José e Maria
        Amigo jose = new Amigo("jose@email.com");
        Amigo maria = new Amigo("maria@email.com");

        sistema.cadastraAmigo("jose", "jose@email.com");
        sistema.cadastraAmigo("maria", "maria@email.com");

        // b) Configurando amigos secretos com tratamento de exceção
        try {
            sistema.configuraAmigoSecretoDe("jose@email.com", "maria@email.com");
            sistema.configuraAmigoSecretoDe("maria@email.com", "jose@email.com");
        } catch (AmigoInexistenteException e) {
            System.out.println("Erro ao configurar amigo secreto: " + e.getMessage());
        }

        // c) Enviando mensagem anônima de Maria para José
        MensagemParaAlguem msg1 = new MensagemParaAlguem(
                "Oi José! Feliz amigo secreto!",
                "maria@email.com",
                true,
                "jose@email.com"
        );
        sistema.listaDeMensagens.add(msg1);

        // d) Enviando mensagem anônima de Maria para todos
        MensagemParaTodos msg2 = new MensagemParaTodos(
                "Feliz amigo secreto para todos!",
                "maria@email.com",
                true
        );
        sistema.listaDeMensagens.add(msg2);

        // e) Pesquisando mensagens anônimas e imprimindo
        System.out.println("=== Mensagens Anônimas ===");
        for (Mensagem m : sistema.pesquisaMensagensAnonimas()) {
            System.out.println(m.getTextoCompletoAExibir());
        }

        // f) Pesquisando amigo secreto de José e verificando se é Maria
        try {
            String amigoDeJose = sistema.pesquisaAmigoSecretoDe("jose@email.com");
            if (amigoDeJose.equals("maria@email.com")) {
                System.out.println("br.ufpb.dcx.amigosecreto.Amigo secreto de José: " + amigoDeJose + " → Ok");
            } else {
                System.out.println("br.ufpb.dcx.amigosecreto.Amigo secreto de José não é Maria.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao pesquisar amigo secreto de José: " + e.getMessage());
        }
    }
}
