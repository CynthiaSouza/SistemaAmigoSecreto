package br.ufpb.dcx.amigosecreto;

import java.util.ArrayList;
import java.util.List;

public class SistemaAmigo {
    private List<Amigo> listaDeAmigos = new ArrayList<>();
    public List<Mensagem> listaDeMensagens = new ArrayList<>();

    public void cadastraAmigo(String nomeAmigo, String emailAmigo) {
        listaDeAmigos.add(new Amigo(nomeAmigo));
    }

    public Amigo pesquisaAmigo(String emailAmigo) throws AmigoInexistenteException {
        for (Amigo a : listaDeAmigos) {
            if (a.getEmail().equals(emailAmigo)) {
                return a;
            }
        }
        throw new AmigoInexistenteException("br.ufpb.dcx.amigosecreto.Amigo com e-mail " + emailAmigo + " não encontrado.");
    }

    public void enviarMensagemParaTodos(String texto, String emailRemetente, boolean ehAnonima) {
        MensagemParaTodos msg = new MensagemParaTodos(texto, emailRemetente, ehAnonima);
        listaDeMensagens.add(msg);
    }

    public void enviarMensagemParaAlguem(String texto, String emailRemetente, String emailDestinatario, boolean ehAnonima) {
        MensagemParaAlguem msg = new MensagemParaAlguem(texto, emailRemetente, ehAnonima, emailDestinatario);
        listaDeMensagens.add(msg);
    }

    public List<Mensagem> pesquisaMensagensAnonimas() {
        List<Mensagem> anonimas = new ArrayList<>();
        for (Mensagem m : listaDeMensagens) {
            if (m.isAnonima()) {
                anonimas.add(m);
            }
        }
        return anonimas;
    }

    public List<Mensagem> pesquisaTodasAsMensagens() {
        return new ArrayList<>(listaDeMensagens);
    }

    public void configuraAmigoSecretoDe(String emailDaPessoa, String emailAmigoSorteado) throws AmigoInexistenteException {
        Amigo amigo = pesquisaAmigo(emailDaPessoa);
        if (amigo == null) {
            throw new AmigoInexistenteException("br.ufpb.dcx.amigosecreto.Amigo com e-mail " + emailDaPessoa + " não encontrado.");
        }
        amigo.setEmailAmigoSorteado(emailAmigoSorteado);
    }

    // + pesquisaAmigoSecretoDe(...)
    public String pesquisaAmigoSecretoDe(String emailDaPessoa) throws AmigoInexistenteException, AmigoNaoSorteadoException {
        Amigo amigo = pesquisaAmigo(emailDaPessoa);
        if (amigo == null) {
            throw new AmigoInexistenteException("br.ufpb.dcx.amigosecreto.Amigo com e-mail " + emailDaPessoa + " não encontrado.");
        }
        String sorteado = amigo.getEmailAmigoSorteado();
        if (sorteado == null) {
            throw new AmigoNaoSorteadoException("br.ufpb.dcx.amigosecreto.Amigo secreto ainda não foi configurado para: " + emailDaPessoa);
        }
        return sorteado;
    }
}
