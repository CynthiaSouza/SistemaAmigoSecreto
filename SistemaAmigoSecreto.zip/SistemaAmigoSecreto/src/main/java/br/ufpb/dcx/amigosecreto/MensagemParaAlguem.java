package br.ufpb.dcx.amigosecreto;

public class MensagemParaAlguem extends Mensagem {
    private String emailDestinatario;

    public MensagemParaAlguem(String texto, String emailRemetente, boolean anonima, String emailDestinatario) {
        super(texto, emailRemetente, anonima);
        this.emailDestinatario = emailDestinatario;
    }

    public String getEmailDestinatario() {
        return emailDestinatario;
    }

    @Override
    public String getTextoCompletoAExibir() {
        if (anonima) {
            return "br.ufpb.dcx.amigosecreto.Mensagem para " + emailDestinatario + ". Texto: " + texto;
        } else {
            return "br.ufpb.dcx.amigosecreto.Mensagem de: " + emailRemetente + " para " + emailDestinatario + ". Texto: " + texto;
        }
    }
}
